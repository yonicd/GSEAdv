context("Testing check-GSC methods")

test_that("isolation", {
  expect_false(isolation(Info))
})
