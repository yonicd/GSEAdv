context("calc.nPathways")



test_that("works", {
  expect_equal(calc.nPathways(6L), 62L)
})

