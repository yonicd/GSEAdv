library(testthat)
library(GSEAdv)

test_check("GSEAdv")
